﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModeloSysacad
{
    class Carrera
    {
        public PEstudios PEstudio { get; set; }
        public Materia Materia { get; set; }
        public string Comision { get; set; }
    }
}
