﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModeloSysacad
{
    class Cursada : Inscripcion
    {
        public int Legajo { get; set; }
    }
}
