﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModeloSysacad
{
    class Alumno : Persona
    {
        public int Legajo { get; set; }
        public DateTime FechaInscripcion { get; set; }
        public string Correo { get; set; }
        public string Contrasenia { get; set; }
        public Materia Materia { get; set; }
        public Carrera Carrera { get; set; }
        public DateTime Horario { get; set; }

    }
}
