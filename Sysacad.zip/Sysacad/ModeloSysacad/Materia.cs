﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModeloSysacad
{
    class Materia
    {
        public Correlatividad Correlatividad { get; set; }
        public int CargaHoraria { get; set; }
        public int Notas { get; set; }
    }
}
