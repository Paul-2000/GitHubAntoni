﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModeloSysacad
{
    class Comision
    {
        public Carrera Carrera { get; set; }
        public Materia Materia { get; set; }
        public string Turno { get; set; }
        public int LegAlumno { get; set; }
        public int LegDocente { get; set; }
        public int LegAyudante { get; set; }
    }
}
