﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModeloSysacad
{
    class Notas
    {
        public Carrera Carrera { get; set; }
        public Materia Materia { get; set; }
        public bool Estado { get; set; }
        public int Calificacion  { get; set; }
    }
}
