﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModeloSysacad
{
    class Docente : Persona
    {
        public int Legajo { get; set; }
        public string Catedra { get; set; }
        public Comision Comision { get; set; }
        public DateTime Horario { get; set; }
    }
}
