﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModeloSysacad
{
    class Usuario
    {
        public int DNI { get; set; }
        public int Clave { get; set; }
        public int Legajo { get; set; }
    }
}
